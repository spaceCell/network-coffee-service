package com.example.network_coffee_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NetworkCoffeeServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
