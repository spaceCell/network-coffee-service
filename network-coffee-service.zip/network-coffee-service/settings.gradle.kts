rootProject.name = "network-coffee-service"
